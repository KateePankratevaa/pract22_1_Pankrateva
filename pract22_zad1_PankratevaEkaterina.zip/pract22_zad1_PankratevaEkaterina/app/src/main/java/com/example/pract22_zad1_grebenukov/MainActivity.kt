package com.example.pract22_zad1_grebenukov

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.pract22_zad1_grebenukov.databinding.ActivityMainBinding
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private lateinit var requestQueue: RequestQueue
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        requestQueue = Volley.newRequestQueue(this)
        binding.btnToGetData.setOnClickListener {
            val city = binding.edNameCity.text.toString()
            getResult(city)
        }
    }
    fun getResult(city: String, ){
         var url = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=f6b4e03ea192e7ad0bae596827e05c7d&units=metric&lang=ru"
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null, Response.Listener { response ->
                val name = response.getString("name")
                val main = response.getJSONObject("main")
                val temp = main.getDouble("temp")
                val pressure = main.getInt("pressure")
                val wind = response.getJSONObject("wind").getDouble("speed")
                val df = DecimalFormat("#")
                binding.tvCityName.text = "Название города: " + name.toString()
                binding.tvTemp.text = "Температура: " + df.format(temp).toString() + " C"
                binding.tvPressure.text = "Давление: " + pressure.toString() + " Па"
                binding.tvWindSpeed.text = "Скорость ветра: " + wind.toString() + " м/c"
            },
            Response.ErrorListener { error ->
                binding.edNameCity.hint = "Ошибка при получении данных: ${error.message}"
            }
        )
        requestQueue.add(jsonObjectRequest)
    }
}